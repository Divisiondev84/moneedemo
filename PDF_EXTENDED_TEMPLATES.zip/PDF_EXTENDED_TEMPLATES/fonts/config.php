<?php 
		
			if(!defined("PDF_EXTENDED_VERSION"))
			{
				return;	
			}
		
		
					$this->fontdata['helveticaneueltstd-ltcn'] = array(
								'R' => 'HelveticaNeueLTStd-LtCn.ttf'
					);
					$this->fontdata['helveticaneueltstd-mdcn'] = array(
								'R' => 'HelveticaNeueLTStd-MdCn.ttf'
					);
					$this->fontdata['helveticaneueltstd-thcn'] = array(
								'R' => 'HelveticaNeueLTStd-ThCn.ttf'
					);
					$this->fontdata['helveticaneueltstd-ultltcn'] = array(
								'R' => 'HelveticaNeueLTStd-UltLtCn.ttf'
					);